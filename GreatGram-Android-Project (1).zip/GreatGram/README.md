# GreatGram Android App

GreatGram is a native Android prototype based on the requested social-media concept and branding.

## Included
- GreatGram branding and logo
- Home feed with stories and posts
- Explore, Reels, Messages, and Profile navigation shells
- Responsive custom-drawn UI
- Dark social-media visual design

## Build
Open this folder in Android Studio and let Gradle sync. Then choose **Build > Build APK(s)**.

The project uses Android Gradle Plugin 8.7.3, compileSdk 35, minSdk 24.

This is a front-end prototype: real accounts, cloud photo/video storage, live messaging, notifications, moderation, and backend APIs still need to be connected before production release.
