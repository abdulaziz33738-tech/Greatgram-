package com.greatgram.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(new GreatGramView(this)); }

    static class GreatGramView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        int tab=0; HashSet<Integer> liked=new HashSet<>(); Bitmap logo; float den;
        String[] tabs={"Home","Explore","Reels","Messages","Profile"};
        String[] people={"Your Story","Sarah","Alex","Maya","Riya","Noah"};
        int[] accent={0xffa855f7,0xff22d3ee,0xffff3d81,0xffffb020,0xff7c3aed};
        GreatGramView(Context c){ super(c); den=getResources().getDisplayMetrics().density; logo=BitmapFactory.decodeResource(getResources(),getResources().getIdentifier("greatgram_logo","drawable",c.getPackageName())); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(2)); setBackgroundColor(0xff070711); }
        float dp(float x){return x*den;}
        void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(dp(size));p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,dp(x),dp(y),p);}
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(dp(l),dp(t),dp(r),dp(b),dp(rad),dp(rad),p);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth()/den;
            // header
            txt(c,"Great",18,32,24,Color.WHITE,true); txt(c,"Gram",74,32,24,0xffc45cff,true);
            txt(c,"✦",w-45,31,22,0xffffc83d,true);
            if(tab==0) drawHome(c,w); else drawPlaceholder(c,w,tabs[tab]); drawNav(c,w);
        }
        void drawHome(Canvas c,float w){
            txt(c,"Good afternoon 👋",18,62,14,0xffa8a8bd,false);
            // stories
            float y=86; for(int i=0;i<people.length;i++){float x=18+i*65; p.setShader(new LinearGradient(dp(x),dp(y),dp(x+50),dp(y+50),accent[i%accent.length],0xffff4da6,Shader.TileMode.CLAMP)); c.drawCircle(dp(x+25),dp(y+25),dp(27),p); p.setShader(null); round(c,x+4,y+4,x+46,y+46,22,0xff151522); txt(c,i==0?"+":"●",x+18,y+31,16,Color.WHITE,true); txt(c,people[i],x-1,y+67,10,0xffdddded,false); }
            drawPost(c,18,176,w-18,0,"travel.with.nia","Bali, Indonesia","Chasing sunsets and good vibes", "12.6K");
            drawPost(c,18,610,w-18,1,"maya.creates","Jodhpur, India","New ideas, new energy ✨", "8.4K");
        }
        void drawPost(Canvas c,float l,float top,float r,int id,String user,String place,String caption,String likes){
            round(c,l,top,r,top+410,18,0xff11111d); txt(c,user,l+14,top+26,14,Color.WHITE,true); txt(c,"⋯",r-25,top+26,20,0xffccccdd,false); txt(c,place,l+14,top+45,11,0xff8e8ea4,false);
            int col=id==0?0xff123a56:0xff4b2360; round(c,l+8,top+58,r-8,top+270,14,col);
            txt(c,id==0?"SUNSET ESCAPE":"CREATE • SHARE • GROW",l+25,top+170,18,0xffffffff,true); txt(c,id==0?"🌅":"✦",r-75,top+190,32,0xffffffff,true);
            txt(c,"♡",l+14,top+300,30,0xffffffff,false); txt(c,"○",l+62,top+300,24,0xffffffff,false); txt(c,"➤",l+104,top+300,22,0xffffffff,false); txt(c,"♡",r-42,top+300,25,0xffffffff,false);
            txt(c,likes+" likes",l+14,top+330,12,Color.WHITE,true); txt(c,user+"  "+caption,l+14,top+353,12,0xffd8d8e2,false); txt(c,"View all comments",l+14,top+378,11,0xff88889e,false);
        }
        void drawPlaceholder(Canvas c,float w,String title){ txt(c,title,18,74,28,Color.WHITE,true); txt(c,"GreatGram is ready for this feature.",18,104,14,0xff9c9caf,false);
            String[] cards={"Smart discovery","Private communities","Creator insights","AI-assisted creation","Better controls","Close friends"};
            for(int i=0;i<cards.length;i++){float x=18+(i%2)*((w-54)/2+18), y=135+(i/2)*120; round(c,x,y,x+(w-54)/2,y+98,18,0xff141421); txt(c,"✦",x+16,y+31,22,accent[i%accent.length],true); txt(c,cards[i],x+16,y+61,14,Color.WHITE,true); txt(c,"Tap to explore",x+16,y+82,10,0xff9292a8,false); }
        }
        void drawNav(Canvas c,float w){float y=getHeight()/den-68; round(c,0,y-10,w,getHeight()/den,0,0xff0b0b16); for(int i=0;i<5;i++){float x=w*(i+.5f)/5; int color=i==tab?Color.WHITE:0xff77778a; String icon=new String[]{"⌂","⌕","▶","✉","◉"}[i]; txt(c,icon,x-9,y+18,24,color,i==tab); txt(c,tabs[i],x-18,y+39,8,color,i==tab);}}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX()/den,y=e.getY()/den; float h=getHeight()/den; if(y>h-85){tab=Math.max(0,Math.min(4,(int)(x/(getWidth()/den)*5)));invalidate();return true;} if(tab==0 && y>250 && y<600){liked.add(1);invalidate();} return true; }
    }
}
